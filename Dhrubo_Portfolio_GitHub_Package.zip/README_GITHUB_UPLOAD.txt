Dhrubo Barua Dip — GitHub deployment package

Upload ALL files and folders in this ZIP to the root of your GitHub repository.

Required structure:
index.html
assets/
  (all exported images and attachments)

Do not upload admin.html to the public repository. Keep admin.html on your computer for editing.
